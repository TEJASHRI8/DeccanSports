package com.cybage.services;

public interface AdminServiceI {

	public String showRole(String role) throws Exception; 
}
