package com.cybage.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.pojos.Batch;
import com.cybage.services.ManagerServiceI;
import com.cybage.services.ManagerServiceImpl;


public class ManagerServlet extends HttpServlet {
	
	ManagerServiceI manager=new ManagerServiceImpl();
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Scanner sc=new Scanner(System.in);
		//Batch batch =new Batch();
		//manager.addSportUI();
		//manager.addBatchUI();
		//manager.removeBatchUI();
		//manager.updateBatchUI();
		//manager.getAllBatchesUI();		
		//manager.removeSportsUI();
				// set cont type
				response.setContentType("text/html");
				// PW --for sending response to clnt
				PrintWriter pw = response.getWriter();
					pw.print("<h4>Login successful</h4> ");
					//retrieve user details from request scope
					//details --request scoped attr
					//email --- request param 
				pw.print("User details " + request.getAttribute("details")+"<br>");
				pw.print("User Email " + request.getParameter("email")+"<br>");
				
	}
				
		
		
		
		
}
	

	

